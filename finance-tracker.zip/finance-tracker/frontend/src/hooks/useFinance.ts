import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "../api/client";
import type { TransactionCreate } from "../types";

// ── Transactions ──────────────────────────────────────────────────────────────

export function useTransactions(month?: string) {
  return useQuery({
    queryKey: ["transactions", month],  // Cache key — refetches when month changes
    queryFn: () => api.getTransactions(month),
  });
}

export function useCreateTransaction() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: TransactionCreate) => api.createTransaction(data),
    onSuccess: () => {
      // Invalidate all transaction and summary queries so the UI refreshes
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      queryClient.invalidateQueries({ queryKey: ["summary"] });
    },
  });
}

export function useDeleteTransaction() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => api.deleteTransaction(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      queryClient.invalidateQueries({ queryKey: ["summary"] });
    },
  });
}

// ── Categories ────────────────────────────────────────────────────────────────

export function useCategories() {
  return useQuery({
    queryKey: ["categories"],
    queryFn: api.getCategories,
  });
}

// ── Summary ───────────────────────────────────────────────────────────────────

export function useSummary(month: string) {
  return useQuery({
    queryKey: ["summary", month],
    queryFn: () => api.getSummary(month),
  });
}

import type { Transaction, TransactionCreate, Category, CategoryCreate, MonthlySummary } from "../types";

// Change this if your backend runs on a different port
const BASE_URL = "http://localhost:8000";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({ detail: "Unknown error" }));
    throw new Error(error.detail || `HTTP ${res.status}`);
  }
  // 204 No Content has no body
  if (res.status === 204) return undefined as T;
  return res.json();
}

// ── Transactions ──────────────────────────────────────────────────────────────
export const api = {
  getTransactions: (month?: string): Promise<Transaction[]> =>
    request(`/transactions${month ? `?month=${month}` : ""}`),

  createTransaction: (data: TransactionCreate): Promise<Transaction> =>
    request("/transactions", { method: "POST", body: JSON.stringify(data) }),

  updateTransaction: (id: number, data: TransactionCreate): Promise<Transaction> =>
    request(`/transactions/${id}`, { method: "PUT", body: JSON.stringify(data) }),

  deleteTransaction: (id: number): Promise<void> =>
    request(`/transactions/${id}`, { method: "DELETE" }),

  // ── Categories ───────────────────────────────────────────────────────────────
  getCategories: (): Promise<Category[]> =>
    request("/categories"),

  createCategory: (data: Omit<Category, "id">): Promise<Category> =>
    request("/categories", { method: "POST", body: JSON.stringify(data) }),

  // ── Summary ──────────────────────────────────────────────────────────────────
  getSummary: (month: string): Promise<MonthlySummary> =>
    request(`/summary?month=${month}`),
};

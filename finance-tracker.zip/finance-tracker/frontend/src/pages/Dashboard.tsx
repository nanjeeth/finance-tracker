import { useState } from "react";
import { useSummary, useTransactions, useCreateTransaction, useDeleteTransaction, useCategories } from "../hooks/useFinance";
import type { TransactionCreate } from "../types";

// Format currency
const fmt = (n: number) => `$${n.toLocaleString("en-US", { minimumFractionDigits: 2 })}`;

// Get current month as "YYYY-MM"
const thisMonth = () => new Date().toISOString().slice(0, 7);

export default function Dashboard() {
  const [month, setMonth] = useState(thisMonth);
  const [showForm, setShowForm] = useState(false);

  const { data: summary, isLoading: summaryLoading } = useSummary(month);
  const { data: transactions = [], isLoading: txLoading } = useTransactions(month);
  const { data: categories = [] } = useCategories();
  const createTx = useCreateTransaction();
  const deleteTx = useDeleteTransaction();

  // Form state
  const [form, setForm] = useState<TransactionCreate>({
    title: "",
    amount: 0,
    type: "expense",
    date: new Date().toISOString().slice(0, 10),
    category_id: null,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createTx.mutateAsync(form);
    setShowForm(false);
    setForm({ title: "", amount: 0, type: "expense", date: new Date().toISOString().slice(0, 10), category_id: null });
  };

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "2rem 1rem", fontFamily: "system-ui, sans-serif" }}>

      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
        <div>
          <h1 style={{ margin: 0, fontSize: "1.75rem", fontWeight: 700 }}>Finance Tracker</h1>
          <p style={{ margin: "0.25rem 0 0", color: "#64748b" }}>Your monthly financial overview</p>
        </div>
        <div style={{ display: "flex", gap: "0.75rem", alignItems: "center" }}>
          <input
            type="month"
            value={month}
            onChange={e => setMonth(e.target.value)}
            style={{ padding: "0.5rem 0.75rem", borderRadius: 8, border: "1px solid #e2e8f0", fontSize: "0.9rem" }}
          />
          <button
            onClick={() => setShowForm(true)}
            style={{ padding: "0.5rem 1.25rem", background: "#6366f1", color: "#fff", border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 600 }}
          >
            + Add
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      {summaryLoading ? (
        <p style={{ color: "#94a3b8" }}>Loading summary…</p>
      ) : summary ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "1rem", marginBottom: "2rem" }}>
          {[
            { label: "Income", value: fmt(summary.total_income), color: "#22c55e" },
            { label: "Expenses", value: fmt(summary.total_expenses), color: "#ef4444" },
            { label: "Net Savings", value: fmt(summary.net_savings), color: summary.net_savings >= 0 ? "#6366f1" : "#f97316" },
            { label: "Savings Rate", value: `${summary.savings_rate}%`, color: "#0ea5e9" },
          ].map(card => (
            <div key={card.label} style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 12, padding: "1.25rem", boxShadow: "0 1px 3px rgba(0,0,0,.06)" }}>
              <div style={{ fontSize: "0.8rem", color: "#94a3b8", marginBottom: "0.25rem" }}>{card.label}</div>
              <div style={{ fontSize: "1.5rem", fontWeight: 700, color: card.color }}>{card.value}</div>
            </div>
          ))}
        </div>
      ) : null}

      {/* Category Breakdown */}
      {summary && summary.category_breakdown.length > 0 && (
        <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 12, padding: "1.25rem", marginBottom: "2rem" }}>
          <h2 style={{ margin: "0 0 1rem", fontSize: "1rem", fontWeight: 600 }}>Spending by Category</h2>
          {summary.category_breakdown.map(cat => (
            <div key={cat.category} style={{ marginBottom: "0.75rem" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.25rem", fontSize: "0.875rem" }}>
                <span style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                  <span style={{ width: 10, height: 10, borderRadius: "50%", background: cat.color, display: "inline-block" }} />
                  {cat.category}
                </span>
                <span style={{ fontWeight: 600 }}>{fmt(cat.total)}</span>
              </div>
              <div style={{ background: "#f1f5f9", borderRadius: 4, height: 6 }}>
                <div style={{
                  width: `${Math.min(100, (cat.total / summary.total_expenses) * 100)}%`,
                  background: cat.color, height: "100%", borderRadius: 4, transition: "width 0.4s ease"
                }} />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Transactions List */}
      <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 12, overflow: "hidden" }}>
        <div style={{ padding: "1.25rem 1.25rem 0.75rem", borderBottom: "1px solid #f1f5f9" }}>
          <h2 style={{ margin: 0, fontSize: "1rem", fontWeight: 600 }}>Transactions ({transactions.length})</h2>
        </div>
        {txLoading ? (
          <p style={{ padding: "1.25rem", color: "#94a3b8" }}>Loading…</p>
        ) : transactions.length === 0 ? (
          <p style={{ padding: "2rem", textAlign: "center", color: "#94a3b8" }}>No transactions for this month yet.</p>
        ) : (
          transactions.map(tx => (
            <div key={tx.id} style={{ display: "flex", alignItems: "center", padding: "0.875rem 1.25rem", borderBottom: "1px solid #f8fafc", gap: "1rem" }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 500, fontSize: "0.9rem" }}>{tx.title}</div>
                <div style={{ fontSize: "0.75rem", color: "#94a3b8" }}>
                  {tx.date} {tx.category && <span style={{ color: tx.category.color }}>· {tx.category.name}</span>}
                </div>
              </div>
              <div style={{ fontWeight: 700, color: tx.type === "income" ? "#22c55e" : "#ef4444" }}>
                {tx.type === "income" ? "+" : "-"}{fmt(tx.amount)}
              </div>
              <button
                onClick={() => deleteTx.mutate(tx.id)}
                style={{ background: "none", border: "none", cursor: "pointer", color: "#cbd5e1", fontSize: "1.1rem", padding: "0 0.25rem" }}
                title="Delete"
              >×</button>
            </div>
          ))
        )}
      </div>

      {/* Add Transaction Modal */}
      {showForm && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50 }}>
          <div style={{ background: "#fff", borderRadius: 16, padding: "2rem", width: "100%", maxWidth: 440, boxShadow: "0 20px 60px rgba(0,0,0,.2)" }}>
            <h2 style={{ margin: "0 0 1.5rem", fontSize: "1.2rem", fontWeight: 700 }}>Add Transaction</h2>
            <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
              <input required placeholder="Title (e.g. Groceries)" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                style={{ padding: "0.625rem 0.875rem", border: "1px solid #e2e8f0", borderRadius: 8, fontSize: "0.9rem" }} />
              <input required type="number" min="0.01" step="0.01" placeholder="Amount" value={form.amount || ""} onChange={e => setForm(f => ({ ...f, amount: parseFloat(e.target.value) }))}
                style={{ padding: "0.625rem 0.875rem", border: "1px solid #e2e8f0", borderRadius: 8, fontSize: "0.9rem" }} />
              <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value as "income" | "expense" }))}
                style={{ padding: "0.625rem 0.875rem", border: "1px solid #e2e8f0", borderRadius: 8, fontSize: "0.9rem" }}>
                <option value="expense">Expense</option>
                <option value="income">Income</option>
              </select>
              <input required type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                style={{ padding: "0.625rem 0.875rem", border: "1px solid #e2e8f0", borderRadius: 8, fontSize: "0.9rem" }} />
              <select value={form.category_id ?? ""} onChange={e => setForm(f => ({ ...f, category_id: e.target.value ? parseInt(e.target.value) : null }))}
                style={{ padding: "0.625rem 0.875rem", border: "1px solid #e2e8f0", borderRadius: 8, fontSize: "0.9rem" }}>
                <option value="">No category</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <div style={{ display: "flex", gap: "0.75rem", marginTop: "0.5rem" }}>
                <button type="button" onClick={() => setShowForm(false)}
                  style={{ flex: 1, padding: "0.625rem", border: "1px solid #e2e8f0", borderRadius: 8, background: "#fff", cursor: "pointer" }}>
                  Cancel
                </button>
                <button type="submit" disabled={createTx.isPending}
                  style={{ flex: 1, padding: "0.625rem", background: "#6366f1", color: "#fff", border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 600 }}>
                  {createTx.isPending ? "Saving…" : "Save"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
